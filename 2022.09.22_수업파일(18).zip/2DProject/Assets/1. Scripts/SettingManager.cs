﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SettingManager : MonoBehaviour
{    
    public GameObject setting; // 설정화면
    public Button settingBtn;  // 설정버튼    
    public Button continueBtn; // 컨티뉴 버튼
    public Button[] HomeBtn;   // 홈 버튼
    public Button[] reStartBtn;// 재시작 버튼

    private void Awake()
    {
        // 설정 버튼에 함수 연결
        settingBtn.onClick.AddListener(ClickSetting);
        continueBtn.onClick.AddListener(ClickContinue);

        HomeBtn[0].onClick.AddListener(ClickHome);
        HomeBtn[1].onClick.AddListener(ClickHome);

        reStartBtn[0].onClick.AddListener(ClickRestart);
        reStartBtn[1].onClick.AddListener(ClickRestart);

        // 일시정지 해제
        Time.timeScale = 1;
    }

    // 설정 버튼 누르면 호출 
    void ClickSetting()
    {
        // 설정화면 띄우기
        setting.SetActive(true);

        // 일시정지
        Time.timeScale = 0;
    }

    // 컨티뉴 버튼 누르면 호출
    void ClickContinue()
    {
        // 설정화면 끄기
        setting.SetActive(false);

        // 일시정지 해제
        Time.timeScale = 1;
    }

    // 홈 버튼 누르면 호출
    void ClickHome()
    {
        // 시작씬으로 전환
        SceneManager.LoadScene("1. StartScene");
    }

    // 재시작 버튼 누르면 호출
    void ClickRestart()
    {
        // 현재 씬을 다시 불러오기
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
