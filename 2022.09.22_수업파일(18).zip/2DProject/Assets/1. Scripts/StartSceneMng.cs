﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; // 씬매니저 클래스 사용하기 위함


public class StartSceneMng : MonoBehaviour
{
    // 시작하기 버튼 누르면 호출
    public void ClickStart()
    {
        // 플레이씬으로 전환
        SceneManager.LoadScene("2. PlayScene");
    }

    // 종료하기 버튼 누르면 호출
    public void ClickQuit()
    {
        // 게임 종료
#if UNITY_EDITOR // 에디터일 경우
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
