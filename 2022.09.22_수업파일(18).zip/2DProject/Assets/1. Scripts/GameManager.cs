﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // UI 컴포넌트 사용하기 위함

public class GameManager : MonoBehaviour
{    
    public GameObject bombPref, potionPref;  // 폭탄, 포션 프리팹을 담을 변수
    public GameObject ending;                // 엔딩화면 게임 오브젝트
    public Transform spawnPoints;            // 스폰 포인트의 부모
    public Image numberImg;                  // 3,2,1 숫자 이미지 컴포넌트
    public Sprite[] numberSprites;           // 숫자 스프라이트 배열
    public Text timeTxt, lifeTxt;            // 시간 텍스트 컴포넌트, 목숨 텍스트
    public float time;                       // 실제 진행 시간
    int sec, min;                            // 초, 분
 
    [HideInInspector]
    public bool isStart;                     // 게임이 진짜 시작됐는지
        
    private int life = 3;                    // 플레이어의 목숨
    public int Life // 프로퍼티
    {
        // 사용
        get { return life; }
        set // 할당
        {
            // 전달 받은 값을 목숨에 적용
            life = value;

            // 목숨 제한
            life = Mathf.Clamp(life, 0, 3);

            // 목숨 텍스트에 출력
            lifeTxt.text = life.ToString();

            // 목숨이 없다면 엔딩
            if(life == 0)
            {
                Ending("게임 오버!");
            }
        }
    }

    private void Start()
    {
        // 시작 전 3,2,1
        //StartCoroutine(BeforeStart());

        // 게임이 시작됐음을 저장
        isStart = true;
    }

    // 폭탄 스폰
    void SpawnBomb()
    {
        // 폭탄 프리팹을 복제해서 스폰 포인트의 자식으로 생성
        Instantiate(bombPref, spawnPoints.GetChild(0));

        // 1초 후에 자기자신 호출
        Invoke("SpawnBomb", Random.Range(0f, 1.5f));
    }

    // 포션 스폰
    void SpawnPotion()
    {
        // 포션 프리팹을 복제해서 스폰 포인트의 자식으로 생성
        Instantiate(potionPref, spawnPoints.GetChild(1));

        // 1초 후에 자기자신 호출
        Invoke("SpawnPotion", Random.Range(1f, 2f));
    }

    // 3,2,1 카운트 세기
    IEnumerator BeforeStart()
    {
        for (int i = 1; i >= 0; i--)
        {
            // 1초 쉬기
            yield return new WaitForSeconds(1);

            // 숫자 이미지 3 > 2 > 1
            numberImg.sprite = numberSprites[i];
        }

        // 1초 쉬기
        yield return new WaitForSeconds(1);

        // 이미지 비활성화
        numberImg.gameObject.SetActive(false);

        // 아이템 스폰
        SpawnBomb();
        SpawnPotion();

        // 게임이 시작됐음을 저장
        isStart = true;
    }

    private void Update()
    {
        // 게임이 시작되지 않았다면 함수 탈출
        if (!isStart)
            return;

        // 실제 시간 구하기
        time += Time.deltaTime;

        // 소숫점자리 없애고 초로 계산
        sec = (int)time;

        // 60초가 되면
        if (sec == 60)
        {
            // 분 증가
            min++;

            // 초 초기화
            time = 0;
        }

        // 시간 텍스트 UI에 출력
        timeTxt.text = min.ToString("00") + ":" + sec.ToString("00");
    }

    // 게임이 끝나면(=플레이어가 죽으면) 호출
    public void Ending(string text)
    {
        // 엔딩화면 띄우기
        ending.SetActive(true);

        // 엔딩화면의 자식인 텍스트에 문구 출력
        ending.GetComponentInChildren<Text>().text = text + "\n살아남은 시간\n" + timeTxt.text;

        // 일시정지
        Time.timeScale = 0;

        // 씬에 있는 모든 아이템을 검색해서 배열에 저장
        FallingItem[] items = FindObjectsOfType<FallingItem>();

        // 배열에 있는 모든 아이템 삭제
        foreach (var item in items)
        {
            Destroy(item.gameObject);
        }
    }
}
