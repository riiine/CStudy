﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FallingItem : MonoBehaviour
{
    // 낙하 속도
    //float speed;

    // Start is called before the first frame update
    void Start()
    {
        // 낙하 속도를 랜덤하게
        GetComponent<Rigidbody2D>().gravityScale = Random.Range(0.9f, 2.5f);

        //speed = Random.Range(3f, 6f);
    }

    // Update is called once per frame
    void Update()
    {
        // 계속 아래로 내려가기
        //transform.position -= new Vector3(0, speed * Time.deltaTime, 0);

        // 화면 아래로 내려갔다면
        //if(transform.position.y < -6)
        //{
        //    // 자기자신 삭제
        //    Destroy(gameObject);
        //}
    }

    // 누군가와 충돌했을 때 호출
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // 자기자신 삭제
        Destroy(gameObject);
    }
}
