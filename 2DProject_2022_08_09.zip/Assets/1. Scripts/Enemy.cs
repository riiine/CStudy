﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    ////-------------- 내가 쓴 답
    //private static Enemy instance = null;

    //private void Awake()
    //{
    //    if (null == instance)
    //    {
    //        instance = this;
    //        DontDestroyOnLoad(this.gameObject);
    //    }
    //    else
    //    {
    //        Destroy(this.gameObject);
    //    }
    //}
    //public static Enemy Instance
    //{
    //    get
    //    {
    //        if (null == instance)
    //        {
    //            return null;
    //        }
    //        return instance;
    //    }
    //}
    ////-------------- 내가 쓴 답

    // 적이 오른쪽으로 이동하는 기능
    // 단, 물리(벨로서티)를 사용하는 방법으로
    Rigidbody2D rigid;

    int dir;
    bool isChange; // 방향을 바꿨는지 아닌지

    Animator anim;

    SpriteRenderer sr;

    void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();

        RandomDir(); 
    }

    private void Update()
    {

        // 왼쪽을 보고 있을 때는 왼쪽으로 0.5만큼
        // 오른쪽을 보고 있을 때는 오른쪽으로 0.5만큼
        // (레이의 위치가)

        // 레이 기즈모 그리기
        Debug.DrawRay(transform.position + new Vector3(dir * 0.6f, 0, 0), Vector2.down);

        if (dir != 0) // 움직일 때만
        {
            // 레이와 닿은 물체 저장
            RaycastHit2D hit = Physics2D.Raycast(transform.position + new Vector3(dir * 0.6f, 0, 0), Vector2.down, 1);

            if (!hit && !isChange) // 닿은 물체가 없다면 = 낭떠러지라면 + 방향을 바꾸기 전이라면
            {
                //// 닿은 물체의 이름 출력
                //print(hit.transform.name);

                // 인보크 중지
                CancelInvoke("RandomDir");

                // 방향 바꾸기
                dir *= -1;

                // 방향 바꿨음을 저장
                isChange = true;

                Dir(); // 애니메이션 + 반전

                // 랜덤한 주기로 반복
                Invoke("RandomDir", Random.Range(2f, 3f));
            }
            else if (hit) // 닿은 물체가 있다면 = 땅을 감지한다면
            {
                // 방향 바꾸기 전으로 초기화
                isChange = false;
            }
        }

        // 내 위치에서 시작해서 오른쪽으로 레이 발사
        //Physics2D.Raycast(transform.position, new Vector2(1, 0));
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //-------------- 내가 쓴 답
        //// 왼쪽, 오른쪽, 안 움직임 세 가지 중에 하나를 랜덤으로
        //int rand = Random.Range(-1, 2);
        //rigid.velocity = new Vector2(rand, rigid.velocity.y);
        //-------------- 내가 쓴 답

        rigid.velocity = new Vector2(dir, rigid.velocity.y);
    }

    void RandomDir()
    {
        // 방향 랜덤으로 정하기
        dir = Random.Range(-1, 2);

        // 랜덤한 주기로 반복
        Invoke("RandomDir", Random.Range(2f, 3f));

        Dir(); // 애니메이션 + 반전
    }

    void Dir()
    {
        // 이동에 맞춰 애니메이션 전환
        anim.SetInteger("dir", dir);

        // 방향에 맞춰 반전
        if(dir < 0) // 왼쪽
        {
            sr.flipX = false;
        }
        else if(dir > 0)
        {
            sr.flipX = true;
        }
    }

    // 죽으면 호출
    public void Dead()
    {
        print("죽음");
        // 죽음 애니메이션 전환
        anim.SetTrigger("dead");

        // 움직이는 코드 중단
        CancelInvoke("RandomDir");
        dir = 0;

        // 충돌 기능도 중단
        GetComponent<BoxCollider2D>().enabled = false;
        rigid.simulated = false;

        // 서서히 사라지다가 삭제
        StartCoroutine(DeadColor());
    }

    // 업데이트 대신 코루틴 함수를 사용했을 때 장점
    // 1. 원하는 타이밍에 사용 가능
    //    (bool 자료형의 변수 필요없음)
    // 2. 가독성 좋음
    // 3. 서서히 할 일을 한 후, 다른 일 하기 편함
    // 단점 : 함수를 끝내지 않으면 계속 돌기 때문에 무겁다
    //        (불필요할 때는 사용X, 잘 끝내기)

    IEnumerator DeadColor()
    {
        float time = 0;

        // 투명해지기 전까지만 반복
        while (sr.color.a != 0)
        {
            time += Time.deltaTime;
            // 2초만에 투명해짐
            sr.color = Vector4.Lerp(Color.white, new Vector4(1, 1, 1, 0), time / 2);

            yield return null; // 한 프레임을 쉬기
        }

        // 투명해진 후에 자기 자신을 삭제
        Destroy(gameObject);
    }
}
