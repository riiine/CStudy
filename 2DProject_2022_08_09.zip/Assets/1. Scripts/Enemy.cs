﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    // 적이 오른쪽으로 이동하는 기능
    // 단, 물리(벨로서티)를 사용하는 방법으로
    Rigidbody2D rigid;

    int dir;
    bool isChange; // 방향을 바꿨는지 아닌지

    Animator anim;

    SpriteRenderer sr;

    void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();

        RandomDir(); 
    }

    private void Update()
    {
        // 왼쪽을 보고 있을 때는 왼쪽으로 0.5만큼
        // 오른쪽을 보고 있을 때는 오른쪽으로 0.5만큼
        // (레이의 위치가)

        // 레이 기즈모 그리기
        Debug.DrawRay(transform.position + new Vector3(dir * 0.6f, 0, 0), Vector2.down);

        if (dir != 0) // 움직일 때만
        {
            // 레이와 닿은 물체 저장
            RaycastHit2D hit = Physics2D.Raycast(transform.position + new Vector3(dir * 0.6f, 0, 0), Vector2.down, 1);

            if (!hit && !isChange) // 닿은 물체가 없다면 = 낭떠러지라면 + 방향을 바꾸기 전이라면
            {
                //// 닿은 물체의 이름 출력
                //print(hit.transform.name);

                // 인보크 중지
                CancelInvoke("RandomDir");

                // 방향 바꾸기
                dir *= -1;

                // 방향 바꿨음을 저장
                isChange = true;

                Dir(); // 애니메이션 + 반전

                // 랜덤한 주기로 반복
                Invoke("RandomDir", Random.Range(2f, 3f));
            }
            else if (hit) // 닿은 물체가 있다면 = 땅을 감지한다면
            {
                // 방향 바꾸기 전으로 초기화
                isChange = false;
            }
        }

        // 내 위치에서 시작해서 오른쪽으로 레이 발사
        //Physics2D.Raycast(transform.position, new Vector2(1, 0));
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //-------------- 내가 쓴 답
        //// 왼쪽, 오른쪽, 안 움직임 세 가지 중에 하나를 랜덤으로
        //int rand = Random.Range(-1, 2);
        //rigid.velocity = new Vector2(rand, rigid.velocity.y);
        //-------------- 내가 쓴 답

        rigid.velocity = new Vector2(dir, rigid.velocity.y);
    }

    void RandomDir()
    {
        // 방향 랜덤으로 정하기
        dir = Random.Range(-1, 2);

        // 랜덤한 주기로 반복
        Invoke("RandomDir", Random.Range(2f, 3f));

        Dir(); // 애니메이션 + 반전
    }

    void Dir()
    {
        // 이동에 맞춰 애니메이션 전환
        anim.SetInteger("dir", dir);

        // 방향에 맞춰 반전
        if(dir < 0) // 왼쪽
        {
            sr.flipX = false;
        }
        else if(dir > 0)
        {
            sr.flipX = true;
        }
    }
}
