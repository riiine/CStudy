﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sorting : MonoBehaviour
{
    // 플레이어의 트랜스폼
    public Transform playerTr;

    // 빌딩의 스프라이트렌더러
    SpriteRenderer sr;

    // Start is called before the first frame update
    void Start()
    {
        // 빌딩의 스프라이트렌더러를 가져와서 저장
        sr = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        // 플레이어가 빌딩보다 앞이라면 (=아래)
        if(playerTr.position.y < transform.position.y)
        {
            // 빌딩을 뒤로
            sr.sortingOrder = -1;
        }

        // 플레이어가 빌딩보다 뒤라면 (=위)
        else
        {
            // 빌딩을 뒤로
            sr.sortingOrder = 1;
        }
    }
}
