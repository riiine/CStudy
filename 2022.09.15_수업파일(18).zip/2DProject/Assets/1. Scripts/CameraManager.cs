﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour
{
    // 플레이어
    public Transform player;

    // 카메라 이동 속도
    public float cameraSpeed;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    void LateUpdate() // 업데이트가 끝나자마자 호출
    {
        // 플레이어의 x,y를 가져오기
        Vector3 target = new Vector3(player.position.x, player.position.y, transform.position.z);

        // 플레이어의 위치로 서서히 이동
        transform.position = Vector3.Lerp(transform.position, target, cameraSpeed * Time.deltaTime);
    }
}
