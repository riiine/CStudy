﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    // 게임매니저 컴포넌트
    public GameManager gm;
    public List<Transform> respawnPoints; // 리스폰포인트들

    Transform respawnPoint; // 실제로 사용될 리스폰포인트
        
    public float maxSpeed;  // 최대 이동 속도
    public float jumpPower; // 점프하는 힘

    Rigidbody2D rigd;
    Animator anim;
    SpriteRenderer sr;

    float h;       // 좌우 움직임
    int jumpCount; // 점프한 횟수

    private void Start()
    {
        rigd = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();

        // 시작하자마자 리스폰포인트를 시작위치로
        respawnPoint = respawnPoints[0];
    }

    // Update is called once per frame
    void Update()
    {
        // 게임이 시작되지 않았다면 함수 탈출
        if (!gm.isStart)
            return;

        Move();

        Jump();
    }

    // 일정한 시간마다 호출 (오차범위 적음)
    private void FixedUpdate()
    {
        // 원하는 방향으로 힘을 가하는 방법
        rigd.AddForce(new Vector2(h, 0), ForceMode2D.Impulse);

        // 속도 x를 제한한 값 저장
        float xClamp = Mathf.Clamp(rigd.velocity.x, -maxSpeed, maxSpeed);

        // 제한된 x 적용
        rigd.velocity = new Vector2(xClamp, rigd.velocity.y);
    }

    // 이동 기능
    void Move()
    {
        // 좌우 움직임 저장
        h = Input.GetAxisRaw("Horizontal");

        // h값에 따라 int값 결정
        anim.SetInteger("h", (int)h);

        if (h > 0) // 오른쪽으로 이동할 때
        {
            sr.flipX = false; // 오른쪽
        }
        else if (h < 0) // 왼쪽으로 이동할 때
        {
            sr.flipX = true; // 왼쪽
        }

        // 좌우 이동키에서 손을 뗐다면
        if (Input.GetButtonUp("Horizontal"))
        {
            // 속도를 0으로 고정해서 멈추게
            rigd.velocity = new Vector2(0, rigd.velocity.y);
        }
    }

    // 점프 기능
    void Jump()
    {
        // 점프 키를 눌렀다면 + 점프를 2번하기 전까지
        if (Input.GetButtonDown("Jump") && jumpCount < 2)
        {
            // 위로 힘을 가해서 점프
            rigd.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);

            jumpCount++; // 점프 횟수 증가

            // 점프 애니메이션으로 전환
            anim.SetBool("isJump", true);
        }
    }

    // 누군가와 충돌했을 때 호출
    private void OnCollisionEnter2D(Collision2D collision)
    {
        switch (collision.gameObject.tag)
        {
            case "Item":
                // 충돌한 상대방이 폭탄이라면
                if (collision.gameObject.name == "Bomb(Clone)")
                {
                    // 목숨 감소
                    gm.Life--;
                }
                // 충돌한 상대방이 포션이라면
                else if (collision.gameObject.name == "Potion(Clone)")
                {
                    // 목숨 증가
                    gm.Life++;
                }
                break;

            case "DeadZone":
            case "Enemy":
                gm.Life--; // 목숨 감소
                // 리스폰 위치에 리스폰
                transform.position = respawnPoint.position;
                break;

            case "Ground": // 점프 횟수를 초기화
                jumpCount = 0;

                // 점프 애니메이션 끝
                anim.SetBool("isJump", false);
                break;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        switch (collision.gameObject.tag)
        {
            case "Ending": // 표지판에 닿았다면
                gm.Ending("성공!"); // 엔딩
                break;

            case "Save":
                // 세이브 포인트의 숫자부분만 잘라서 정수로 저장
                int index = int.Parse(collision.gameObject.name.Split('_')[1]);

                // 세이브 포인트의 숫자와 사용 중인 리스폰 포인트의 숫자를 비교
                if(index > respawnPoints.IndexOf(respawnPoint))
                {
                    // 세이브 포인트 번호에 맞는 리스폰 포인트를 사용
                    respawnPoint = respawnPoints[index];
                }

                // 세이브 포인트의 자식을 활용해도 됨
                //respawnPoint = collision.transform.GetChild(0);

                //// 세이브포인트 1에 닿았다면
                //if (collision.gameObject.name == "SavePoint1")
                //{
                //    // 리스폰포인트 1을 사용
                //    respawnPoint = respawnPoints[1];
                //}
                //// 세이브포인트 2에 닿았다면
                //else if (collision.gameObject.name == "SavePoint2")
                //{
                //    // 리스폰포인트 2을 사용
                //    respawnPoint = respawnPoints[2];
                //}
                break;
        }
    }
}
