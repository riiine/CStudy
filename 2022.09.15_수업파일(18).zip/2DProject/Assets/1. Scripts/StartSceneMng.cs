﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; // 씬매니저 클래스 사용하기 위함

public class StartSceneMng : MonoBehaviour
{
    // 외부 컴포넌트를 가져오는 방법
    // 1. 퍼블릭으로 직접 드래그로 할당 : 개발자
    // 2. 검색해서 찾아오기 (검색 함수) : 컴퓨터

    // 내가 갖고있는 컴포넌트를 가져오는 방법
    // ㄴ 대상한테서 컴포넌트 가져오기

    // 타이틀의 게임오브젝트 컴포넌트
    public GameObject title;

    public Transform tr;

    private void Start()
    {
        // 검색 함수 3가지
        //FindObjectOfType<GameObject>(); // 유일한 컴포넌트 검색
        //title = GameObject.Find("Title"); // 이름 검색
        //GameObject.FindGameObjectWithTag("Title"); // 태그 검색

        // 특정 대상한테서 가져오는데 대상이 없음 = 나한테 가져옴
        //tr = GetComponent<Transform>();

        // 특정 대상한테서 가져오려면 앞에 대상 붙이기
        tr = title.GetComponent<Transform>();

        // GetComponent<GameObject>() == gameObject
        // GetComponent<Transform>() == transform
    }

    // 시작하기 버튼 누르면 호출
    public void ClickStart()
    {
        // 플레이씬으로 전환
        SceneManager.LoadScene("2. PlayScene");
    }
}
